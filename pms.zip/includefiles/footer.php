<?php
echo "
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<hr width='60%'>
<p style='font-family: Courier New; font-size: 12px;'>Performance Management System PMS &copy; ".date('Y')."</p>";
?>