<?php
$current_cycle_year = 2022;
$next_cycle_year  = 2023;
?>