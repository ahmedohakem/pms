<script src="graph/jquery-1.12.4.min.js"></script>
<script src="graph/canvasjs.min.js"></script>
 
<?php
	$dataPoints = array(
	array("y" => $NumberOfRecord1Var, "label" => "Processed"),
	array("y" => $NumberOfRecord2Var, "label" => "No Objectives"),
	array("y" => $NumberOfRecord3Var, "label" => "Not Processed"),
	);
	
	
?>
 
<div id="chartContainer"></div>
 
<script type="text/javascript">
 
$(function () {
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Situation in Graph"
	},
	data: [
	{
		type: "column",                
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}
	]
});
chart.render();
});
</script>